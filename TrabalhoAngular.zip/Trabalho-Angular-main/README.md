# Trabalho Angular

Projeto desenvolvido em angular. A aplicação tem como objetivo seguir o fluxo de um CRUD, create, update,delete e read. Tem toda a rotina de cadastro de uma agenda de contatos.
Usando Json Serve

HOME
![alt text](./imgs/home.png)

Listagem de Contatos
![alt text](./imgs/list.png)

Criar/Adicionar Contato
![alt text](./imgs/create.png)

Atualizar Contato
![alt text](./imgs/update.png)